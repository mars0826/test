# -*- coding: utf-8 -*-

from .beta import *

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'filters': {
        'add_request_info': {
            '()': 'utils.log.filters.RequestInfoFilter',
        }
    },
    'handlers': {
        'root_handler': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'encoding': 'utf8',
            'filename': '/var/log/mqtt-im/exhook9200/exhook.log',
            'formatter': 'verbose',
            'maxBytes': 1024 * 1024 * 50,
            'backupCount': 10
        },
    },
    'formatters': {
        'verbose': {
            'format': '%(asctime)s - %(name)s:%(lineno)s - %(levelname)s - %(message)s',
        },
    },
    'root': {
        'handlers': ['root_handler'],
        'level': 'INFO',
        'propagate': True,
    },
}
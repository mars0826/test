# -*- coding: utf-8 -*-

from .local import *

IS_CELERY = True
# -*- coding: utf-8 -*-
import django

django.setup()

from django.conf import settings
import paho.mqtt.client as mqtt
import json
from mqtt.service import aclservice
from mqtt.service import blackservice
from mqtt.service.imuserservice import get_decrypt_password
from utils.log import logfactory
from mqtt.service.blackservice import aes_decrypt_im_message
from mqtt.service.emqxservice import delete_acl_cache
import traceback
logger = logfactory.get_logger(__name__)


# The callback for when the client receives a CONNACK response from the server.
def on_connect(client, userdata, flags, rc):
    logger.info("Connected with result code " + str(rc))
    # Subscribing in on_connect() means that if we lose the connection and
    # reconnect then subscriptions will be renewed.
    topic = settings.EMQ_BLACK_MANAGER_USERNAME
    client.subscribe(topic)
    logger.info("订阅系统主题:{}".format(topic))


# The callback for when a PUBLISH message is received from the server.
def on_message(client, userdata, msg):
    """解析blacklist数据接口，操作黑名单"""
    logger.info("message username:{}".format(client._username))
    payload = msg.payload.decode('utf-8')
    try:
        if payload == 'offline':
            return
        payload_dict = json.loads(payload)
        logger.info("on_message:{}".format(payload_dict))
        if payload_dict['body']['type'] == 'cmd' and payload_dict['body']['custom_event'] == 'black_list':
            encrypt_black_list = payload_dict['body']['custom_exts']['black_list']
            decrypt_black_list_str = aes_decrypt_im_message(encrypt_black_list)
            black_list_dict = json.loads(decrypt_black_list_str)
            action = black_list_dict['action']
            from_username = payload_dict['from']
            # json 字符串解析
            deny_username = black_list_dict['im_username']
            result = False
            if action == 'add_black_list':
                logger.info("add_black_list:from_username:{}:deny_username:{}".format(
                    from_username,
                    deny_username
                ))
                result = aclservice.add_black_list(
                    from_username=from_username,
                    deny_username=deny_username
                )
                delete_acl_cache()
            elif action == 'remove_black_list':
                logger.info('remove_black_list:from_username:{}:deny_username:{}'.format(
                    from_username,
                    deny_username
                ))
                result = aclservice.remove_black(
                    from_username=from_username,
                    deny_username=deny_username
                )
                delete_acl_cache()
            elif action == 'is_in_black_list':
                logger.info('is_in_black_list:from_username:{}:deny_username:{}'.format(
                    from_username,
                    deny_username
                ))
                result = aclservice.is_in_black_list(
                    from_username=from_username,
                    deny_username=deny_username
                )

            blackservice.reply_msg(
                client=client,
                to_username=from_username,
                im_username=deny_username,
                result=result,
                action=action
            )
    except Exception:
        logger.info("blacklist-error:{}".format(traceback.format_exc()))


if __name__ == '__main__':
    username = settings.EMQ_BLACK_MANAGER_USERNAME
    password = get_decrypt_password(username)
    client = mqtt.Client(client_id=username)
    client.username_pw_set(username=username, password=password)
    mqtt_host = settings.EMQ_HOST
    mqtt_port = settings.EMQ_PORT
    client.connect(mqtt_host, mqtt_port, 60)
    client.on_connect = on_connect
    client.on_message = on_message

    # Blocking call that processes network traffic, dispatches callbacks and
    # handles reconnecting.
    # Other loop*() functions are available that give a threaded interface and a
    # manual interface.
    client.loop_forever()

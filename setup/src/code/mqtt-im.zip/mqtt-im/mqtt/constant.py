# -*- coding: utf-8 -*-"
from enum import Enum


class EAllowType(Enum):
    DENY = 0
    ALLOW = 1


class EAceesType(Enum):
    SUBSCRIBE = 1
    PUBLISH = 2
    PUBSUB = 3


class EChatType(Enum):
    SINGLE = 'single'
    GROUP = 'group'
    BROADCAST = 'broadcast'
    CS = 'cs'


class EMessageStatus(Enum):
    PUBLISH = 'publish'  # 发布
    DELIVERED = 'delivered'  # 送达
    DROPPED = 'dropped'  # 丢弃



class ECustomEvent(Enum):
    SINGLE_DEVICE_LOGIN = 'single_device_login'  # 单设备登陆

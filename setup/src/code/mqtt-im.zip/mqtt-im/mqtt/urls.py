from django.conf.urls import url
from mqtt import views

urlpatterns = [
    url(r'^mqtt/token', views.token),
    url(r'^mqtt/user', views.get_user),
    url(r'^mqtt/create_user', views.create_user),
    url(r'^mqtt/send_msg$', views.send_msg),
    url(r'^mqtt/send_msg_to_topics$', views.send_msg_to_topics),
    url(r'^mqtt/test$', views.test)
]

# -*- coding: utf-8 -*-
from rest_framework import serializers


class GetTokenSerializer(serializers.Serializer):
    client_id = serializers.CharField()
    client_secret = serializers.CharField()


class CreateUserSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField()


class GetUserSerializer(serializers.Serializer):
    username = serializers.CharField()


class AclSerializer(serializers.Serializer):
    from_username = serializers.CharField()
    deny_username = serializers.CharField()


class GetBlackListSerializer(serializers.Serializer):
    from_username = serializers.CharField()

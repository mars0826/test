#!/usr/bin/env python
# -*- coding: utf-8 -*-

from utils.redis import redis_db_key
from utils.client.redis import redis_db_client
from utils.redis.base_cache import BaseSuffixString


class UserNameClientid(BaseSuffixString):
    db = redis_db_client
    redis_key = redis_db_key.USERNAME_CLIENTID
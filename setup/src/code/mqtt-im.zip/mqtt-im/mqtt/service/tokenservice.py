# -*- coding: utf-8 -*-
from mqtt.models import ApiClient, ApiToken
from utils.service.encryptservice import encrypt_password
import time


def get_token(client_id: str, client_secret: str) -> str:
    now = int(time.time())
    token = encrypt_password(client_id, "{}{}".format(client_secret, now))
    m_client = ApiClient.objects.filter(
        client_id=client_id, client_secret=client_secret
    ).first()
    ApiToken.objects.create(
        api_client_id=m_client.id,
        token=token
    )
    return token


def check_token(token: str) -> bool:
    return ApiToken.objects.filter(token=token).exists()
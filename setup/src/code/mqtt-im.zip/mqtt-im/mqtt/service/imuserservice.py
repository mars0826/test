# -*- coding: utf-8 -*-
from mqtt.models import User
from utils.common.exceptions import APIException
from utils.common.errorcode import INVALID_ARGS, REPEAT_REGISTER
from datetime import datetime
from utils.common.util import random_str
from utils.service import encryptservice


def add_im_user(user_info: dict) -> dict:
    if User.objects.filter(username=user_info['username']).exists():
        raise APIException(error_code=REPEAT_REGISTER, msg='用户名重复{}'.format(user_info['username']))
    else:
        salt = random_str()
        password = encryptservice.encrypt_password(password=user_info['password'], salt=salt)
        aes_password = encryptservice.encrypt(user_info['password'])
        user_info = dict(
            username=user_info['username'],
            password=password,
            aes_password=aes_password,
            salt=salt,
            created=datetime.now(),
            is_superuser=user_info.get('is_superuser', 0)
        )
        m_user = User.objects.create(**user_info)
        m_user.save()
        return user_info


def get_im_user(username: str) -> dict:
    filter_args = dict(
        username=username
    )
    m_user = User.objects.filter(
        **filter_args
    ).first()
    if m_user:
        return m_user.to_dict()
    return {}


def get_decrypt_password(username: str) -> str:
    m_user = get_im_user(username=username)
    if m_user:
        return encryptservice.decrypt(m_user['aes_password'])
    return ''


def is_user_exists(username: str) -> bool:
    return User.objects.filter(username=username).exists()
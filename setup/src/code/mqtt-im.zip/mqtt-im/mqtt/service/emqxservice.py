# -*- coding: utf-8 -*-
import requests
from requests.auth import HTTPBasicAuth
from django.conf import settings
from utils.log import logfactory

logger = logfactory.get_logger(__name__)


def delete_acl_cache():
    if settings.IS_CLEAN_ACL_CACHE:
        logger.info("delete acl cache")
        url = "{}/api/v4/acl-cache".format(settings.EMQX_API_HOST)
        auth = HTTPBasicAuth('admin', 'public')
        response = requests.delete(url=url, auth=auth)
        response_dict = response.json()
        return response_dict['code']
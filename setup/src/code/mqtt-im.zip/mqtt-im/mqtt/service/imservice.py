# -*- coding: utf-8 -*-
from datetime import datetime, timedelta
import requests
import time
from requests.adapters import HTTPAdapter

from mqtt.models import Message, MsgSendRecord
from django.conf import settings
import json
from mqtt.constant import EChatType, EMessageStatus
from mqtt.service import noticeservice
from mqtt.cache import UserNameClientid
from utils.log import logfactory

logger = logfactory.get_logger(__name__)


def get_now():
    # 13 位
    return int(time.time() * 1000)


def handle_publish_message(send_user: str,
                           from_user: str,
                           to_user: str,
                           topic: str,
                           mqtt_message_id: str,
                           payload_dict: dict,
                           message_no: str):
    """
    消息持久化
    :return:
    """
    message = Message.objects.create(
        send_user=send_user,
        from_user=from_user,
        to_user=to_user,
        topic=topic,
        chat_type=payload_dict.get('chat_type', EChatType.SINGLE.value),
        time_stamp=payload_dict.get('time_stamp', get_now()),
        body=json.dumps(payload_dict.get('body', '')),
        ext=json.dumps(payload_dict.get('ext', '')),
        message_no=message_no
    )
    MsgSendRecord.objects.create(
        mqtt_message_id=mqtt_message_id,
        message=message,
        message_status=EMessageStatus.PUBLISH.value
    )


def save_mqtt_record(mqtt_message_id: str, message_no: str):
    # 关联消息id,保存mqtt消息记录
    m_message = Message.objects.filter(message_no=message_no).first()
    MsgSendRecord.objects.create(mqtt_message_id=mqtt_message_id, message=m_message)


def handle_delivered_message(mqtt_message_id: str):
    m_mqtt_send_record = MsgSendRecord.objects.filter(mqtt_message_id=mqtt_message_id).first()
    if m_mqtt_send_record:
        m_mqtt_send_record.message_status = EMessageStatus.DELIVERED.value
        m_mqtt_send_record.save()
        m_message = m_mqtt_send_record.message
        m_message.is_deleted = True
        m_message.save()


def send_offline_msg(to_username: str):
    filter_args = dict(
        topic=to_username,
        is_deleted=False
    )
    m_message_set = Message.objects.filter(**filter_args)
    if not m_message_set:
        return
    new_message_list = list(m_message_set.all())
    m_message_set.update(is_deleted=True)
    for item in new_message_list:
        item_dict = item.to_dict()
        if item_dict["send_user"]:
            payload_dict = {
                'from': item_dict['from_user'],
                'to': item_dict['to_user'],
                'body': json.loads(item_dict['body']),
                'ext': json.loads(item_dict['ext']),
                'message_no': item_dict['message_no'],
                'time_stamp': item_dict['time_stamp'],
                'chat_type': item_dict['chat_type']
            }
        else:
            payload_dict = json.loads(item_dict['body'])
        ret = send_mqtt_msg(topic=item_dict['topic'], payload=payload_dict)
        logger.info("send_mqtt_msg ret:{}:time:{}".format(ret, datetime.now()))


def exist_offline_msg(topic: str):
    filter_args = dict(
        topic=topic,
        is_deleted=False
    )
    return Message.objects.filter(**filter_args).exists()


def send_mqtt_msg(topic: str, payload: dict) -> bool:
    url = '{}/api/v4/mqtt/publish'.format(settings.EMQX_API_HOST)
    session = requests.Session()
    session.mount("http://", HTTPAdapter(max_retries=3))
    try:
        resp = session.post(
            url=url,
            auth=(settings.EMQX_API_USERNAME, settings.EMQX_API_PASSWORD),
            json=dict(
                topic=topic,
                clientid='mqtt-client',
                payload=json.dumps(payload),
                qos=0
            )
        )
    except Exception as e:
        logger.info('send_mqtt_msg topic:{}, payload:{}, ex:{}'.format(topic, payload, e))
        return False
    if resp.status_code != 200:
        return False
    resp_json = json.loads(resp.text)
    logger.info('send offline message resp: {}'.format(resp_json))
    return resp_json['code'] == 0


def send_msg_to_topics(topics: str, payload: dict) -> bool:
    url = '{}/api/v4/mqtt/publish_batch'.format(settings.EMQX_API_HOST)
    try:
        resp = requests.post(
            url=url,
            auth=(settings.EMQX_API_USERNAME, settings.EMQX_API_PASSWORD),
            json=[dict(
                topics=topics,  # 同时发布消息到多个主题
                clientid='mqtt-client',
                payload=json.dumps(payload),
                qos=0
            )]
        )
    except Exception as e:
        logger.info('send_msg_to_all topic:{}, payload:{}, ex:'.format(topics, payload, e))
        return False
    if resp.status_code != 200:
        return False
    resp_json = json.loads(resp.text)
    return resp_json['code'] == 0


def handle_dropped_message(mqtt_message_id: str):
    MsgSendRecord.objects.filter(
        mqtt_message_id=mqtt_message_id
    ).update(message_status=EMessageStatus.DROPPED.value)


def is_message_illegal(payload_dict: dict, real_from_user: str) -> bool:
    """
    消息是否非法
    """
    if settings.BETA:
        return False
    if real_from_user in ["mqtt-client"]:
        return False
    # username 下是否有对应的clientid(real_from_user)
    if payload_dict.get('from') != real_from_user:
        if UserNameClientid(payload_dict.get('from')).get() != real_from_user:
            return True
    if real_from_user in settings.EMQ_SYSTEM_USERNAMES or payload_dict.get('to') in settings.EMQ_SYSTEM_USERNAMES:
        return False
    chat_type = payload_dict.get('chat_type')
    if chat_type == EChatType.CS.value:
        return False
    if chat_type != EChatType.SINGLE.value:
        return True
    msg_type = payload_dict.get('body', {}).get('type')
    if msg_type != 'txt':
        return True
    return not noticeservice.check_msg_valid(payload_dict)


def clear_expired_message():
    end_time = datetime.now() - timedelta(days=30)
    for i in range(1, 10000):
        first_message = Message.objects.first()
        if first_message.created_time >= end_time:
            break
        logger.info('delete message:{}'.format(Message.objects.filter(
            pk__lte=first_message.pk + 2000
        ).delete()))

    for i in range(1, 10000):
        first_msg_record = MsgSendRecord.objects.first()
        if first_msg_record.create_time >= end_time:
            break
        logger.info('delete msgsendrecord:{}'.format(MsgSendRecord.objects.filter(
            pk__lte=first_msg_record.pk + 3000
        ).delete()))

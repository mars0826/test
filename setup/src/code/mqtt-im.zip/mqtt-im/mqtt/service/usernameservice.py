#!/usr/bin/env python
# -*- coding: utf-8 -*-
from mqtt.service import imservice
from utils.log import logfactory
from mqtt.constant import EChatType, ECustomEvent
from mqtt.service.blackservice import aes_encrypt_im_message
from django.conf import settings
logger = logfactory.get_logger(__name__)

# @Desc    : 通过id生成唯一的邀请码，支持最大id为(len(code_chars)**6 - start_num)/10

start_num = 100000001
code_chars = ['v', 'i', '8', 'h', '6', '7', 'y', 'r', 'l', '2', '3', 's', '0',
              'k', 'm', '9', 'f', '5', 'z', '4', 'q', 'x', 'e',  'u', 'j', 'g',
              'w', 't', 'n', 'b', 'a', 'p']


def gen_im_username(user_id: int):
    # 加上起始数后逆序
    new_id = int(str(user_id * 10 + start_num)[::-1])
    code = []
    while new_id:
        code_index = new_id % len(code_chars)
        code.insert(0, code_chars[code_index])
        new_id = int((new_id - code_index) / len(code_chars))
    return ''.join(code)


def restore_id(code: str):
    new_id = 0
    for code_char in code:
        if code_char not in code_chars:
            return False, None
        new_id = code_chars.index(code_char) + new_id * len(code_chars)
    return True, int((int(str(new_id)[::-1]) - start_num) / 10)


def send_other_device_login_message(to_topic: str):
    alert_message_encrypt_str = aes_encrypt_im_message('您的账号在另一台设备登录')
    payload_dict = {
        'from': settings.EMQ_SYSTEM_ASSISTANT_IM_USERNAME,
        'to': to_topic,
        'chat_type': EChatType.SINGLE.value,
        'body': {
            'type': 'cmd',
            'custom_event': ECustomEvent.SINGLE_DEVICE_LOGIN.value,
            'custom_exts': {
                'alert_message':alert_message_encrypt_str
            }
        }
    }

    ret = imservice.send_mqtt_msg(topic=to_topic, payload=payload_dict)
    logger.info("send_other_device_login_message,to_topic:{} ret:{}".format(to_topic, ret))

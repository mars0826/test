# -*- coding: utf-8 -*-
import json

import requests
from django.conf import settings

from mqtt.service import banner_user
from utils.log import logfactory

logger = logfactory.get_logger(__name__)


def callback(post_data: dict):
    if not settings.NOTICE_URL:
        return
    """
       通知第三方平台
       :return:
    """
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }
    try:
        s = requests.Session()
        s.post(url=settings.NOTICE_URL, headers=headers, json=post_data, timeout=8)
    except Exception as ex:
        logger.error("callback exception {}".format(ex))
        return ''


def check_msg_valid(post_data: dict) -> bool:
    if not settings.CHECK_URL:
        return True
    """
       检查消息是否正常
       :return:正常返回True，异常返回False
    """
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }
    try:
        s = requests.Session()
        resp = s.post(url=settings.CHECK_URL, headers=headers, json=post_data, timeout=8)
        if resp.status_code != 200:
            return True
        resp_json = json.loads(resp.text)
        valid = resp_json.get('valid', False)
        if resp_json.get('code') == '10003':
            banner_user.banned_user(post_data['from'], 24)
        return valid
    except Exception as ex:
        logger.error("check_msg_valid exception {}".format(ex))
        return True


def notice_third_user_offline(username: str, reason: str):
    if not settings.NOTICE_OFFLINE_URL:
        return
    """
       通知第三方平台用户下线
       :param: username 用户名
       :param: reason 离线原因
       :return:
    """
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }
    try:
        logger.info("request url:{},username:{}, reason:{}".format(settings.NOTICE_OFFLINE_URL, username, reason))
        s = requests.Session()
        post_data = dict(
            username=username,
            reason=reason
        )
        s.post(url=settings.NOTICE_OFFLINE_URL, headers=headers, json=post_data, timeout=8)
    except Exception as ex:
        logger.error("notice_third_user_offline exception {}".format(ex))


def notice_third_user_online(username: str):
    if not settings.NOTICE_ONLINE_URL:
        return
    if not username.startswith('cs_'):
        return
    """
       通知第三方平台用户上线
       :param: username 用户名
       :return:
    """
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }
    try:
        logger.info("request url:{},username:{}".format(settings.NOTICE_ONLINE_URL, username))
        s = requests.Session()
        post_data = dict(
            username=username,
        )
        s.post(url=settings.NOTICE_ONLINE_URL, headers=headers, json=post_data, timeout=8)
    except Exception as ex:
        logger.error("notice_third_user_online exception {}".format(ex))
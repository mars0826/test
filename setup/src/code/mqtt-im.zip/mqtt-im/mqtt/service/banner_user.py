# -*- coding: utf-8 -*-

from requests.adapters import HTTPAdapter
import requests
from django.conf import settings
from utils.log import logfactory
import time
import json
from mqtt.service.emqxservice import delete_acl_cache
logger = logfactory.get_logger(__name__)


def banned_user(im_username: str, banned_hour: int):
    """
    添加用户到黑名单
    :param im_username: im 用户名
    :param banned_hour: 禁止的小时数
    :return:
    """
    url = '{}/api/v4/banned'.format(settings.EMQX_API_HOST)
    session = requests.Session()
    session.mount("http://", HTTPAdapter(max_retries=3))
    try:
        resp = session.post(
                url=url,
                auth=(settings.EMQX_API_USERNAME, settings.EMQX_API_PASSWORD),
                json={
                    "who": im_username,
                    "as": 'username',
                    "reason": "example",
                    "until": int(time.time()) + 60 * 60 * banned_hour
                }
            )
        logger.info(resp.text)
        delete_acl_cache()
    except Exception as e:
        logger.info('banned_user username:{}, {}'.format(im_username, e))
        return False
    if resp.status_code != 200:
        return False
    resp_json = json.loads(resp.text)
    logger.info('add blackuser resp: {}'.format(resp_json))
    return resp_json['code'] == 0


def get_banner_users() -> dict:
    """
    获取黑名单用户
    :return:
    """
    url = '{}/api/v4/banned'.format(settings.EMQX_API_HOST)
    session = requests.Session()
    session.mount("http://", HTTPAdapter(max_retries=3))
    try:
        resp = session.get(
            url=url,
            auth=(settings.EMQX_API_USERNAME, settings.EMQX_API_PASSWORD),
        )
        logger.info(resp.text)
    except Exception as e:
        return {}
    if resp.status_code != 200:
        return {}
    return json.loads(resp.text)


def delete_banned_user(im_username: str) -> bool:
    """
    将用户从黑名单中移除
    :param im_username: im 用户名
    :return:
    """
    url = '{}/api/v4/banned/{}/{}'.format(settings.EMQX_API_HOST, 'username', im_username)
    session = requests.Session()
    session.mount("http://", HTTPAdapter(max_retries=3))
    try:
        resp = session.delete(
            url=url,
            auth=(settings.EMQX_API_USERNAME, settings.EMQX_API_PASSWORD)
        )
        logger.info(resp.text)
        delete_acl_cache()
    except Exception as e:
        logger.info('banned_user username:{}, {}'.format(im_username, e))
        return False
    if resp.status_code != 200:
        return False
    resp_json = json.loads(resp.text)
    logger.info('remove blackuser resp: {}'.format(resp_json))
    return resp_json['code'] == 0
# -*- coding: utf-8 -*-
import time
from django.conf import settings
import json
from Crypto.Cipher import AES
import base64
from utils.log import logfactory
logger = logfactory.get_logger(__name__)


class AESUtils:
    def __init__(self, aes_key: str, aes_iv: str):
        self.key = aes_key
        self.mode = AES.MODE_CBC
        self.iv = aes_iv

    def encrypt(self, text):
        """
        需要加密的文本，长度必须为 16 的倍数，不够的位补全
        """
        # text = json.dumps(text, cls=DateEncoder)
        aes = AES.new(self.key, self.mode, self.iv)
        s = text.encode()
        pad = s + ((AES.block_size - len(s) % AES.block_size) * chr(
            AES.block_size - len(s) % AES.block_size)).encode()
        secret = aes.encrypt(pad)
        # 加密后返回的是二进制数据，需要base64转为字符串
        secret = base64.b64encode(secret).decode()
        return secret

    def decrypt(self, secret):
        """
        解密时先将文本base64解密再操作
        """
        aes = AES.new(self.key, self.mode, self.iv)
        plain_text = aes.decrypt(base64.b64decode(secret.encode())).decode()
        return plain_text.strip('\t\x06\x08\x10\x0c\x0f')


def aes_encrypt_im_message(txt: str) -> str:
    aes_util = AESUtils(settings.IM_MESSAGE_AES_KEY, settings.IM_MESSAGE_AES_IV)
    return aes_util.encrypt(txt)


def aes_decrypt_im_message(txt: str) -> str:
    aes_util = AESUtils(settings.IM_MESSAGE_AES_KEY, settings.IM_MESSAGE_AES_IV)
    return aes_util.decrypt(txt).strip().strip('\x01\x02\x03\x04\x05\x06\x07\x08\x09\x10\x0a\x0b\x0c\x0d\x0e\x0f')


def reply_msg(client, to_username: str, im_username: str, result: bool, action: str):
    time_stamp = int(time.time() * 1000)
    black_list_dict = {
                    "action": action,
                    "im_username": im_username,
                    "result": result
                }
    black_list_encrypt_str = aes_encrypt_im_message(json.dumps(black_list_dict))
    payload_json = {
        "from": settings.EMQ_BLACK_MANAGER_USERNAME,
        "to": to_username,
        "chat_type": "single",
        "time_stamp": time_stamp,
        "offline_send": False,
        "body": {
            "type": "cmd",
            "custom_event": "black_list",
            "custom_exts": {
                "black_list": black_list_encrypt_str
            }
        },
        "ext": {},
    }
    reply_payload_str = json.dumps(payload_json)
    logger.info("publish to {}".format(to_username))
    client.publish(topic=to_username, payload=reply_payload_str)

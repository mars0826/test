# -*- coding: utf-8 -*-
from mqtt.models import Acl
from mqtt.constant import EAllowType, EAceesType
from utils.log import logfactory
logger = logfactory.get_logger(__name__)

def add_black_list(from_username: str, deny_username: str):
    try:
        topic = from_username
        m_acl = Acl.objects.create(
            allow=EAllowType.DENY.value,
            username=deny_username,
            access=EAceesType.PUBLISH.value,
            topic=topic
        )
        m_acl.save()
        return True
    except Exception as e:
        logger.info(e)
        return False


def get_black_list(from_username: str):
    topic = from_username
    filter_args = dict(
        allow=EAllowType.DENY.value,
        access=EAceesType.PUBLISH.value,
        topic=topic
    )
    m_acl_set = Acl.objects.filter(**filter_args).values('username')
    black_list = [m_acl['username'] for m_acl in m_acl_set]
    return black_list


def remove_black(from_username: str, deny_username: str):
    try:
        topic = from_username
        Acl.objects.filter(
            allow=EAllowType.DENY.value,
            username=deny_username,
            access=EAceesType.PUBLISH.value,
            topic=topic
        ).delete()
        return True
    except Exception as e:
        logger.info(e)
        return False


def is_in_black_list(from_username: str, deny_username: str):
    topic = from_username
    return  Acl.objects.filter(
        allow=EAllowType.DENY.value,
        username=deny_username,
        access=EAceesType.PUBLISH.value,
        topic=topic
    ).exists()
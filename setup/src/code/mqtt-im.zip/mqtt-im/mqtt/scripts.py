# -*- coding: utf-8 -*-
from mqtt.service.imuserservice import add_im_user
from mqtt.models import ApiClient


def gen_system_user():
    userinfos = [
        dict(
            username='apple001',
            password='123456',
            is_superuser=1
        ),
        dict(
            username='apple002',
            password='123456',
            is_superuser=1
        ),
        dict(
            username='apple003',
            password='123456',
            is_superuser=1
        ),
        dict(
            username='apple004',
            password='123456',
            is_superuser=1
        ),
        dict(
            username='7777',
            password='123456',
            is_superuser=1
        ),
    ]
    for userinfo in userinfos:
        add_im_user(userinfo)


def gen_client():
    client_info = dict(
        client_id='08SuFNrk5ZFSbmt4',
        client_secret='3yVSgPd5mIW5rLBv'
    )
    ApiClient.objects.create(**client_info)
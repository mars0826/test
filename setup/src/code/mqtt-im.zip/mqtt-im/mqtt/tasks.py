# -*- coding: utf-8 -*-
from celery import shared_task

from mqtt.service import imservice


@shared_task
def send_offline_msg(to_username: str):
    imservice.send_offline_msg(to_username)


@shared_task
def clear_expired_message():
    imservice.clear_expired_message()

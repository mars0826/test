# -*- coding: utf-8 -*-
from django.views.decorators.http import require_GET, require_POST
from mqtt.service.imuserservice import add_im_user, get_im_user
from utils.common.decorators import validate_data
from mqtt.service import tokenservice, imservice
from mqtt.service.imuserservice import is_user_exists
from mqtt.serializers import  GetUserSerializer,CreateUserSerializer, GetTokenSerializer
from utils.log import logfactory
logger = logfactory.get_logger(__name__)


@require_POST
@validate_data(GetTokenSerializer)
def token(request, cleaned_data):
    access_token = tokenservice.get_token(
        client_id=cleaned_data['client_id'],
        client_secret=cleaned_data['client_secret']
    )
    return dict(access_token=access_token)


@require_GET
@validate_data(GetUserSerializer)
def get_user(request, cleaned_data):
    """
    :param: username
    :return:
    """
    user = get_im_user(cleaned_data['username'])
    return user


@require_POST
@validate_data(CreateUserSerializer)
def create_user(request, cleaned_data):
    """
    :params: username 注册到IM平台的用户名
    :return:
    """
    user = add_im_user(cleaned_data)
    return user


@require_POST
def send_msg(request):
    cleaned_data = request.data
    logger.info(cleaned_data)
    topic = cleaned_data['to']
    if is_user_exists(username=topic) or topic == 'online_group':
        result = imservice.send_mqtt_msg(topic=topic, payload=cleaned_data)
    else:
        result = False
    return dict(
        send_status=result
    )


@require_POST
def send_msg_to_topics(request):
    # 批量发送消息
    cleaned_data = request.data.dict()
    topics = cleaned_data.pop('to_topics')
    logger.info("cleaned_data:{}".format(cleaned_data))
    result = imservice.send_msg_to_topics(topics=topics, payload=cleaned_data)
    return dict(
        send_status=result
    )


@require_GET
def test(request):
    # 测试用
    # imservice.send_offline_msg('100411')
    return dict(
        send_status=True
    )

# -*- coding: utf-8 -*-
from django.db import models


class User(models.Model):
    username = models.CharField(max_length=100, null=True, unique=True)
    password = models.CharField(max_length=100, null=True)
    # 可逆加密密码，解密后获取明文
    aes_password = models.CharField(max_length=100, null=True)
    salt = models.CharField(max_length=35, null=True)
    is_superuser = models.IntegerField(default=0)
    created = models.DateTimeField(default=None)

    def to_dict(self):
        return dict(
            username=self.username,
            created=self.created,
            password=self.password,
            aes_password=self.aes_password,
            salt=self.salt
        )


class Acl(models.Model):
    # 允许或拒绝 '0: deny, 1: allow'
    allow = models.IntegerField(default=1)
    ipaddr = models.CharField(max_length=60, null=True)
    username = models.CharField(max_length=100, null=True)
    clientid = models.CharField(max_length=100, null=True)
    # 权限控制 1: subscribe, 2: publish, 3: pubsub
    access = models.IntegerField(null=False)
    topic = models.CharField(max_length=100, default='', null=False)
    created_time = models.DateTimeField(auto_now_add=True)

    def to_dict(self):
        return dict(
            username=self.username,
            access=self.access,
            topic=self.topic,
        )

    class Meta:
        unique_together = [
            'username', 'topic'
        ]


class Message(models.Model):
    send_user = models.CharField(max_length=100, null=False, default='')  # 发送者
    from_user = models.CharField(max_length=100, null=False)  # 来源用户
    to_user = models.CharField(max_length=100, null=False)
    chat_type = models.CharField(max_length=10, null=False)
    time_stamp = models.BigIntegerField(null=True)
    body = models.TextField()
    ext = models.TextField()
    # 消息唯一编号
    message_no = models.CharField(max_length=100, null=True, unique=True)
    topic = models.CharField(max_length=100, null=True, db_index=True)
    is_deleted = models.BooleanField(default=False)
    created_time = models.DateTimeField(auto_now_add=True)
    updated_time = models.DateTimeField(auto_now=True)

    def to_dict(self):
        return dict(
            send_user=self.send_user,
            from_user=self.from_user,
            to_user=self.to_user,
            chat_type=self.chat_type,
            time_stamp=self.time_stamp,
            body=self.body,
            ext=self.ext,
            message_no=self.message_no,
            topic=self.topic,
            is_deleted=self.is_deleted,
            created_time=self.created_time,
            updated_time=self.updated_time
        )


class ApiClient(models.Model):
    # 请求接口的客户端
    client_id = models.CharField(max_length=100, null=False)
    client_secret = models.CharField(max_length=100, null=False)
    create_time = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['client_id', 'client_secret']


class ApiToken(models.Model):
    token = models.CharField(max_length=100, db_index=True)
    api_client = models.ForeignKey(ApiClient, on_delete=models.CASCADE, related_name='api_token_client_id', db_constraint=False)
    create_time = models.DateTimeField(auto_now_add=True)


class MsgSendRecord(models.Model):
    # emqx内部消息id
    mqtt_message_id = models.CharField(max_length=100, unique=True)
    message = models.ForeignKey(Message, on_delete=models.CASCADE, related_name='msg_send_record', db_constraint=False)
    create_time = models.DateTimeField(auto_now_add=True)
    message_status = models.CharField(max_length=10)  # 消息状态

# -*- coding: utf-8 -*-

"""
  RedisKey定义
"""


class RedisKey:
    """RedisKey类对象"""
    def __init__(self, prefix, ex=None):
        self.prefix = prefix
        self.ex = ex

    # 生成key值
    def __call__(self, key):
        return self.prefix + str(key)

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
redis结构的封装，避免方法重写
"""
import logging
import random
from typing import Set, List

from redis.client import list_or_args

from utils.client import redis_db_client

logger = logging.getLogger(__file__)


class BaseCache:
    db = redis_db_client
    name = None

    @classmethod
    def expire(cls, time, is_force: bool = False):
        if is_force or cls.db.ttl(cls.name) == -1:
            return cls.db.expire(cls.name, time)
        return 1

    @classmethod
    def expireat(cls, when, is_force: bool = False):
        if is_force or cls.db.ttl(cls.name) == -1:
            return cls.db.expireat(cls.name, when)
        return 1

    @classmethod
    def delete(cls):
        cls.db.delete(cls.name)

    @classmethod
    def unlink(cls):
        # 异步删除
        return cls.db.unlink(cls.name)

    @classmethod
    def ttl(cls):
        return cls.db.ttl(cls.name)


class BaseSuffixCache:
    """ 带后缀字段的缓存 """
    db = redis_db_client
    redis_key = None

    def __init__(self, suffix=''):
        self.name = self.redis_key(suffix)

    def delete(self):
        return self.db.delete(self.name)

    def unlink(self):
        # 异步删除
        return self.db.unlink(self.name)

    def expire(self, is_force: bool = False):
        if not self.redis_key.ex:
            return
        if is_force or self.db.ttl(self.name) == -1:
            self.db.expire(self.name, self.redis_key.ex)

    def expireat(self, when):
        self.db.expireat(self.name, when)

    def ttl(self):
        return self.db.ttl(self.name)

    def exists(self):
        return self.db.exists(self.name)


class BaseInt(BaseSuffixCache):
    def get(self) -> (bool, int):
        value = self.db.get(self.name)
        if value is None:
            return False, None
        else:
            return True, int(value)

    def set(self, value):
        self.db.set(self.name, value)
        super().expire(True)


class BaseString(BaseCache):

    @classmethod
    def get(cls):
        return cls.db.get(cls.name)

    @classmethod
    def set(cls, value):
        return cls.db.set(cls.name, value)


class BaseSuffixString(BaseSuffixCache):

    def get(self):
        return self.db.get(self.name)

    def set(self, value):
        return self.db.set(self.name, value)


class BaseZSet(BaseSuffixCache):

    def rem(self, members, *args):
        """ 支持单个或列表删除 """
        args = list_or_args(members, args)
        return self.db.zrem(self.name, *args)

    def rembyscore(self, min_score: float = '-inf', max_score: float = '+inf'):
        return self.db.zremrangebyscore(self.name, min_score, max_score)

    def set(self, member, value: float):
        self.db.zadd(self.name, {member: value})
        super().expire(True)

    def batch_set(self, member_list, value_list):
        self.db.zadd(self.name, dict(zip(member_list, value_list)))
        super().expire(True)

    def increase(self, member, amount: int = 1) -> float:
        super().expire(True)
        return self.db.zincrby(self.name, amount, member)

    def decrease(self, member, amount: int = 1) -> float:
        super().expire(True)
        return self.db.zincrby(self.name, -amount, member)

    def get(self, member) -> int:
        data = self.db.zscore(self.name, member)
        return int(data or 0)

    def exists(self):
        return self.db.exists(self.name)

    def range(self, min_score: int = '-inf', max_score: int = '+inf',
              start=None, num=None,
              withscores=False, reverse=False, score_cast_func=int):
        args = dict(
            name=self.name,
            min=min_score,
            max=max_score,
            start=start,
            num=num,
            withscores=withscores,
            score_cast_func=score_cast_func
        )
        if reverse:
            return self.db.zrevrangebyscore(
                **args
            )
        else:
            return self.db.zrangebyscore(
                **args
            )

    def all_members(self):
        return self.db.zrange(
            name=self.name,
            start=0,
            end=-1
        )


class BaseClassZSet(BaseCache):
    db = redis_db_client
    name = None
    expired_time = 30 * 24 * 60 * 60

    @classmethod
    def remove(cls, members, *args):
        """ 支持单个或列表删除 """
        args = list_or_args(members, args)
        return cls.db.zrem(cls.name, *args)

    @classmethod
    def remove_invalid(cls, min_score='-inf', max_score=0):
        cls.db.zremrangebyscore(cls.name, min=min_score, max=max_score)

    @classmethod
    def set(cls, member, value: float):
        cls.db.zadd(cls.name, {member: value})
        if cls.expired_time != -1:
            cls.db.expire(
                name=cls.name,
                time=cls.expired_time
            )

    @classmethod
    def increase(cls, member, amount: int = 1) -> float:
        return cls.db.zincrby(cls.name, amount, member)

    @classmethod
    def decrease(cls, member, amount: int = 1) -> float:
        return cls.db.zincrby(cls.name, -amount, member)

    @classmethod
    def get(cls, member) -> int:
        data = cls.db.zscore(cls.name, member)
        return int(data or 0)

    @classmethod
    def exist(cls, member) -> bool:
        return cls.db.zscore(cls.name, member) is not None

    @classmethod
    def exist_and_get(cls, member) -> (bool, int):
        data = cls.db.zscore(cls.name, member)
        return data is not None, int(data or 0)

    @classmethod
    def count(cls) -> int:
        return cls.db.zcard(cls.name)

    @classmethod
    def zrevrank(cls, member):
        return cls.db.zrevrank(cls.name, member)

    @classmethod
    def range(cls, min_score: int = '-inf', max_score: int = '+inf',
              start=None, num=None,
              withscores=False, reverse=False, score_cast_func=float):
        args = dict(
            name=cls.name,
            min=min_score,
            max=max_score,
            start=start,
            num=num,
            withscores=withscores,
            score_cast_func=score_cast_func
        )
        if reverse:
            return cls.db.zrevrangebyscore(
                **args
            )
        else:
            return cls.db.zrangebyscore(
                **args
            )


class BaseIntSet(BaseSuffixCache):

    def sadd(self, value):
        self.db.sadd(self.name, value)
        super().expire(True)

    def sismember(self, value):
        return self.db.sismember(self.name, value)

    def batch_sadd(self, values):
        if not values:
            return
        self.db.sadd(self.name, *set(values))
        super().expire(True)

    def batch_srem(self, values):
        if not values:
            return
        self.db.srem(self.name, *set(values))
        super().expire(True)

    def get_all(self):
        return [
            int(item) for item in self.db.smembers(self.name)
        ]

    def get_random_list(self, count: int = 10):
        items = [
            int(item) for item in self.db.srandmember(self.name, number=count)
        ]
        random.shuffle(items)
        return items

    def count(self):
        return self.db.scard(self.name)


class BaseSet(BaseCache):
    db = redis_db_client
    name = None

    @classmethod
    def add(cls, values, *value):
        values = list_or_args(values, value)
        if not values:
            return
        cls.db.sadd(cls.name, *values)

    @classmethod
    def count(cls):
        return cls.db.scard(cls.name)

    @classmethod
    def remove(cls, *values):
        cls.db.srem(cls.name, *values)

    @classmethod
    def exist(cls, value) -> bool:
        return cls.db.sismember(cls.name, value)

    @classmethod
    def all(cls) -> Set:
        return cls.db.smembers(cls.name)

    @classmethod
    def random(cls, count: int) -> List:
        return cls.db.srandmember(cls.name, count)


class BaseHash(BaseCache):
    @classmethod
    def hmset(cls, value: dict):
        cls.db.hmset(
            cls.name,
            value
        )

    @classmethod
    def hexists(cls, key) -> bool:
        return cls.db.hexists(
            cls.name, key
        )

    @classmethod
    def hincrby(cls, key, amount=1):
        cls.db.hincrby(cls.name, key=key, amount=amount)

    @classmethod
    def hgetall(cls):
        return cls.db.hgetall(cls.name)

    @classmethod
    def hset(cls, key, value):
        cls.db.hset(
            cls.name, key, value
        )

    @classmethod
    def hget(cls, key) -> (bool, str):
        value = cls.db.hget(
            cls.name, key
        )
        if value is None:
            return False, None
        else:
            return True, value

    @classmethod
    def hdel(cls, keys, *key):
        keys = list_or_args(keys, key)
        if not keys:
            return
        cls.db.hdel(cls.name, *keys)


class BaseSuffixHash(BaseSuffixCache):

    def hmset(self, value: dict):
        self.db.hmset(
            self.name,
            value
        )

    def hexists(self, key) -> bool:
        return self.db.hexists(
            self.name, key
        )

    def hincrby(self, key, amount=1):
        self.db.hincrby(self.name, key=key, amount=amount)
        super().expire(True)

    def hgetall(self):
        return self.db.hgetall(self.name)

    def hset(self, key, value):
        self.db.hset(
            self.name, key, value
        )
        super().expire(True)

    def hget(self, key) -> (bool, str):
        value = self.db.hget(
            self.name, key
        )
        if value is None:
            return False, None
        else:
            return True, value

    def hdel(self, key):
        self.db.hdel(self.name, key)


class CustomHash(BaseCache):
    @classmethod
    def hmset(cls, name: str, value: dict):
        cls.db.hmset(
            name,
            value
        )

    @classmethod
    def hgetall(cls, name: str):
        return cls.db.hgetall(name)


class BaseIntHash(BaseHash):

    @classmethod
    def hget(cls, key) -> (bool, int):
        value = cls.db.hget(
            cls.name, key
        )
        if value is None:
            return False, -1
        else:
            return True, int(value)

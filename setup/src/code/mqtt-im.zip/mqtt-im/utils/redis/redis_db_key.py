# -*- coding: utf-8 -*-


from .rediskey import RedisKey

USERNAME_CLIENTID = RedisKey(prefix='username_clientid_', ex=30 * 24 * 3600)  # username关联的clientid

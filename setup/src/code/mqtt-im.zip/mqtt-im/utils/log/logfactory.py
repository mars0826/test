#!/usr/bin/env python
# -*- coding: utf-8 -*-

# @Time    : 2018/9/20 上午10:13

# @File    : logger.py
# @Desc    :
import logging
from django.conf import settings

from celery.utils import log as celery_log


def get_logger(name: str):
    if settings.IS_CELERY:
        return celery_log.get_task_logger(name)
    else:
        return logging.getLogger(name)

# -*- coding: utf-8 -*-"

import logging
from functools import wraps
from importlib import import_module
from inspect import isfunction

from django.views import View
from django.http import HttpRequest
from django.db import close_old_connections
from utils.common.exceptions import APIException
from utils.common import errorcode

logger = logging.getLogger(__name__)


def validate_form(form_class):
    """
    校验表单的decorator

    :param form_class: django.forms.Form的子类
    """

    def decorator(func):

        @wraps(func)
        def wrapper(*args, **kwargs):

            request = args[0]
            if not isinstance(request, HttpRequest):
                raise Exception("view的第一个参数必须是request,如果用于class-based view,"
                                "请使用@method_decorator(require_login)")

            form = form_class(request.data)
            if not form.is_valid():
                raise APIException(errorcode.INVALID_ARGS, msg=form.errors)

            return func(*args, **kwargs, cleaned_data=form.cleaned_data)

        return wrapper

    return decorator


def validate_data(serializer_class):
    """
    校验serializer
    """

    def decorator(func):

        @wraps(func)
        def wrapper(*args, **kwargs):

            request = args[0]
            if not isinstance(request, HttpRequest):
                raise Exception("view的第一个参数必须是request,如果用于class-based view,"
                                "请使用@method_decorator(require_login)")

            # 支持在http method为PATCH时的增量更新
            partial = True if request.method == 'PATCH' else False
            serializer = serializer_class(data=request.data, partial=partial)
            if not serializer.is_valid():
                error_messages = []
                for value in serializer.errors.values():
                    if isinstance(value, list) and value:
                        value = value[0]
                    error_messages.append("".join(str(value)))
                error_messages = "\n".join(error_messages)
                func_name = getattr(func, '__name__', func)
                logger.info("{}验证错误: {}".
                            format(func_name, serializer.errors))
                raise APIException(errorcode.INVALID_ARGS, error_messages)
            return func(*args, **kwargs, cleaned_data=serializer.validated_data)

        return wrapper

    return decorator


def copy_headers_to_data(headers=()):
    """
    将HTTP请求头复制到`request.data`中

    :param headers:
        需要复制的header列表，目前支持的header一共有五个：
        ip, api_version, app_version, auth_token, device_id, device_info
        header在utils/middleware/gatemiddleware.py中定义
    :return:
    """

    def decorator(func):

        @wraps(func)
        def wrapper(*args, **kwargs):
            request = args[0]
            if not isinstance(request, HttpRequest):
                raise Exception("view的第一个参数必须是request,如果用于class-based view,"
                                "请使用@method_decorator(copy_headers_to_data)")
            for header in headers:
                if header not in [
                    'ip', 'api_version',
                    'app_version', 'auth_token', 'device_id', 'device_info'
                ]:
                    raise Exception("HTTP header {}不存在，不能进行复制".format(header))
                request.data = request.data.copy()
                request.data[header] = getattr(request, header)
            return func(*args, **kwargs)

        return wrapper

    return decorator


def versioning(origin_object):
    """
    接口版本装饰器, 不同版本的服务不需要改变url,只要在请求中定义'X-Api-Version',以及定义不同版本的接口方法
    param: origin_object, 被装饰的对象可以是class View或者func

    使用方法:
        1. 装饰class view: 给class加上@versioning装饰器,
           在类中定义各种版本的方法 "[http_method]_[version]",例如 get_v2, post_v3

        2. 装饰func: 给和url绑定的func加上@versioning装饰器,
           在模块中, 定义该func各种版本的方法 "[func_name]_[version]",同一个方法的不同版本要保证func_name一致

           ***!!! 注意当func有多个装饰器时,将 @versioning 放在最上面,匹配到正确的方法再去执行其他的decorator !!!***
    """

    def dispatch(self, request, *args, **kwargs):
        methods = []
        for i in dir(origin_object):
            if i.startswith(request.method.lower()) and i != request.method.lower():
                methods.append(i)

        if request.method.lower() in self.http_method_names:
            if request.api_version:
                handler = getattr(self, get_adaptive_method(request.api_version.lower(), request.method.lower(), methods),
                                  self.http_method_not_allowed)
            else:
                handler = getattr(self, request.method.lower(),
                                  self.http_method_not_allowed)
        else:
            handler = self.http_method_not_allowed
        return handler(request, *args, **kwargs)

    @wraps(origin_object)
    def wrapper(*args, **kwargs):
        api_version = args[0].api_version
        if not api_version:
            return origin_object(*args, **kwargs)
        else:
            module = origin_object.__module__
            module = import_module(module)
            members = dir(module)
            methods = [member for member in members if
                       member.startswith(origin_object.__name__) and member != origin_object.__name__]

            version_func = get_adaptive_method(
                api_version, origin_object.__name__, methods)

            if version_func != origin_object.__name__:
                func_call = getattr(module, version_func)
                return func_call(*args, **kwargs)
            else:
                return origin_object(*args, **kwargs)

    if isfunction(origin_object):
        return wrapper

    if issubclass(origin_object, View):
        origin_object.dispatch = dispatch
        return origin_object


def get_adaptive_method(version, http_method, methods):
    """
    根据version匹配方法,向下最大匹配的原则,找不到当前版本,就向下取最大版本号的方法
    """
    if http_method + '_' + version in methods:
        return http_method + '_' + version
    # example: 把func_v3, 按照数字3逆序排序
    methods.sort(key=lambda method: int(
        method.rpartition('_')[-1][1:]), reverse=True)

    for method in methods:
        if int(version[1:]) >= int(method.rpartition('_')[-1][1:]):
            return method
    return http_method


def parse_kwargs(function):
    """
    将某个函数的所有关键字参数存入其第一个参数中。

    Examples:

    @parse_kwargs
    def func(kwargs, var1=1, var2=2):
        for field in ['var1', 'var2']:
            if(kwargs.get(field)):
                print(kwargs.get('field'))
    """
    @wraps(function)
    def wrapper(*args, **kwargs):
        return function(kwargs, *args, **kwargs)

    return wrapper


def close_old_database_connections(func):
    """
    解决 mysql Lost connection to MySQL server during query
    在数据库操作前加上本装饰器，通过django.db.close_old_connections防止连接丢失
    """
    def wrapper(*args, **kwargs):
        close_old_connections()
        return func(*args, **kwargs)
    return wrapper

import random
import string
from datetime import datetime


def random_str(n: int = 4):
    seed = "1234567890abcdefghijklmnopqrstuvwxyz"
    sa = []
    for i in range(n):
        sa.append(random.choice(seed))
    salt = ''.join(sa)
    return salt


def gen_order_no():
    """生成一个随机唯一的编号"""
    return datetime.now().strftime('%y%m%d%H%M%S') + ''.join(random.sample(string.digits, 8))

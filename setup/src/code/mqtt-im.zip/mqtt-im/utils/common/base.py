# -*- coding: utf-8 -*-
import re


def is_regx_match(regx_urls, url):
    """
    判断给定的url路径是否不包含在特定的正则表达式路径
    eg: 判断当前请求是否要登录，如果在不需要登录的接口url数组中匹配不到，
        则调用该接口需要登录
    """
    sign_request_match = [re.compile(url_regx) for url_regx in regx_urls]

    for regex in sign_request_match:
        if regex.match(url):
            return True
    return False

#!/usr/bin/env python3
# -*- coding: utf-8 -*-"


class APIException(Exception):
    """
    业务异常类
    """
    def __init__(self, error_code, msg=None, data=None):
        """
        exception的构造函数
        :param error_code: 错误码
        :param msg: 错误信息
        :param data: 此异常相关的数据
        """
        self.status = error_code.id
        self.msg = msg if msg else error_code.msg
        self.data = data

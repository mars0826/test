# -*- coding: utf-8 -*-"
import collections

ErrorCode = collections.namedtuple('ErrorCode', 'id msg')
INVALID_ARGS = ErrorCode(id=777, msg='不合法的参数')

REPEAT_REGISTER = ErrorCode(id=1001, msg='重复注册')
# -*- coding: utf-8 -*-"
from django_redis import get_redis_connection


class RedisClient:

    def __init__(self, alias):
        self.db_write = get_redis_connection(alias, True)
        self.db_read = get_redis_connection(alias, False)

        for func_name in dir(self.db_read):
            if func_name.startswith('_') or func_name in ['RESPONSE_CALLBACKS']:
                continue
            if func_name in ['exists', 'get', 'getbit', 'getrange', 'hexists', 'mget',
                             'hget', 'hgetall', 'hkeys', 'hlen', 'hmget', 'hstrlen',
                             'keys', 'lindex', 'llen', 'lrange', 'ltrim',
                             'randomkey', 'scard', 'sismember', 'smembers', 'srandmember',
                             'strlen', 'ttl', 'zcard', 'zcount', 'zrange', 'zrangebylex',
                             'zrangebyscore', 'zrank', 'zrevrange', 'zrevrangebylex',
                             'zrevrangebyscore', 'zrevrank']:
                self.__dict__[func_name] = getattr(self.db_read, func_name)
            else:
                self.__dict__[func_name] = getattr(self.db_write, func_name)


redis_db_client = RedisClient("default")

# -*- coding: utf-8 -*-"

from .redis import redis_db_client

__all__ = [
    'redis_db_client',
]

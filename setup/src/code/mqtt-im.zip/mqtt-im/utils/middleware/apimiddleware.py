#!/usr/bin/env python3
# -*- coding: utf-8 -*-"
from urllib.parse import quote

import six
from datetime import datetime
from django.utils.deprecation import MiddlewareMixin
from django.http import HttpResponse, JsonResponse, FileResponse
from rest_framework.parsers import JSONParser, FormParser, BaseParser
from utils.middleware.middlewareutil import convert_exception_to_response


class APIMiddleware(MiddlewareMixin):
    def process_request(self, request):
        request.data = request.GET
        content_type = request.META.get('CONTENT_TYPE')
        stream = self.get_stream(request)
        if stream:
            if not content_type or 'application/json' in content_type:
                parser = JSONParser()
            elif 'multipart/form-data' in content_type:
                return
            else:
                parser = FormParser()
            try:
                request.data = parser.parse(stream, media_type=content_type)
            except:
                raise
        return

    def process_response(self, request, response):
        """拦截所有的dict类型的HTTP响应，并封装成协议要求的格式，以JsonResponse的形式返回回去
        """
        assert isinstance(response, dict) \
               or isinstance(response, list) \
               or isinstance(response, HttpResponse) \
               or isinstance(response, FileResponse), \
            "未知的view返回类型: {}".format(type(response))

        if not isinstance(response, HttpResponse) and not isinstance(response, FileResponse):
            print('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
            wrap_data = dict(
                timestamp=datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
                status=0,
                message="OK",
            )
            if isinstance(response, dict):
                wrap_data.update(dict(
                    data=response
                ))
            elif isinstance(response, list):
                wrap_data.update(dict(
                    data={
                        'items': response,
                        'total': len(response),
                    }
                ))

            response = JsonResponse(wrap_data)
        return response

    def process_exception(self, request, exception):
        return convert_exception_to_response(exception, request)

    @staticmethod
    def get_stream(request):
        """将Http请求的body当做一个流返回
        """
        meta = request.META
        try:
            content_length = int(
                meta.get('CONTENT_LENGTH', meta.get('HTTP_CONTENT_LENGTH', 0))
            )
        except (ValueError, TypeError):
            content_length = 0

        if content_length == 0:
            stream = None
        elif not request._read_started:
            stream = request
        else:
            stream = six.BytesIO(request.body)

        return stream

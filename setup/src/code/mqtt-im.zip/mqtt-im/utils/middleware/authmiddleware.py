#!/usr/bin/env python3
# -*- coding: utf-8 -*-"
import json
import logging
from utils.common.base import is_regx_match
from django.utils.deprecation import MiddlewareMixin
from django.contrib.auth.models import User
from utils.common.exceptions import APIException
from utils.middleware.middlewareutil import convert_exception_to_response
from utils.common.errorcode import INVALID_ARGS
from django.conf import settings
from mqtt.service.tokenservice import check_token
auth_exclude_urls = settings.AUTH_EXCLUDE_URLS

logger = logging.getLogger(__name__)


class APIAuthMiddleware(MiddlewareMixin):
    def process_request(self, request):
        """
        拦截request
        """
        if is_regx_match(regx_urls=auth_exclude_urls, url=request.path):
            return

        auth_token = request.META.get('HTTP_AUTH_TOKEN')
        is_exists =  check_token(auth_token)
        if not is_exists:
            return convert_exception_to_response(
                APIException(error_code=INVALID_ARGS, msg='unauth')
            )

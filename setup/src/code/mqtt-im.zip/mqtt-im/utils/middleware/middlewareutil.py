#!/usr/bin/env python3
# -*- coding: utf-8 -*-"
import threading
import logging

from datetime import datetime

from django.forms.utils import ErrorDict
from django.http import JsonResponse

from utils.common.exceptions import APIException

logger = logging.getLogger(__name__)


# 线程本地变量，贯穿整个请求，用来保存该上下文中需要保持追踪的数据
REQUEST_THREAD_LOCAL = threading.local()


def convert_exception_to_response(exception, request=None):
    if isinstance(exception, APIException):
        response = dict(
            status=exception.status,
            # 如果返回类型为ErrorDict(forms.errors), 将其转换成str
            message=exception.msg if not isinstance(
                exception.msg, ErrorDict) else exception.msg.as_text(),
            timestamp=datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
            data=exception.data if exception.data else {},
        )
        return JsonResponse(response)


def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip


def get_appinfo_in_request(request):
    return '{method}:{api_version}, {host}, {api_url}, device:{device_id}, {device_info}, {app_code}, {app_version}, {channel_code}'.format(
        method=request.method.upper(), api_url=request.path,
        device_id=request.META.get('HTTP_X_DEVICE_ID'),
        device_info=request.META.get('HTTP_X_DEVICE_INFO'),
        app_code=request.META.get('HTTP_X_APP_CODE'),
        app_version=request.META.get('HTTP_X_APP_VERSION'),
        channel_code=request.META.get('HTTP_X_CHANNEL_ID'),
        api_version=request.META.get('HTTP_X_API_VERSION'),
        host=request.META.get('HTTP_HOST')
    )

# -*- coding: utf-8 -*-
"""
获取AES加密、解密后的key值
"""
import base64
from Crypto.Cipher import AES
import hashlib

AES_KEY = '13b45239-e066-4c'
AES_IV = '1c60c6f0-5cb7-40'


def encrypt(plain_key):
    """加密key值"""
    cipher = AES.new(key=AES_KEY.encode('utf-8'), mode=AES.MODE_CBC, IV=AES_IV.encode('utf-8'))
    s = plain_key.encode()
    pad = s + ((AES.block_size - len(s) % AES.block_size) * chr(AES.block_size - len(s) % AES.block_size)).encode()
    encrypted_bytes = cipher.encrypt(pad)
    return base64.b64encode(encrypted_bytes).decode()


def decrypt(encrypted_key):
    """解密key值"""
    cipher = AES.new(key=AES_KEY.encode('utf-8'), mode=AES.MODE_CBC, IV=AES_IV.encode('utf-8'))
    plain_key = cipher.decrypt(base64.b64decode(encrypted_key.encode())).decode()
    return plain_key.strip('\x01\x02\x03\x04\x05\x06\x07\x08\x09\x10\x0a\x0b\x0c\x0d\x0e\x0f').rstrip('\n')


def encrypt_password(password: str, salt: str) -> str:
    """加密密码"""
    return hashlib.sha256("{}{}".format(salt, password).encode('utf-8')).hexdigest()

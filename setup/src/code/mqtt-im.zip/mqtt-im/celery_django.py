# -*- coding: utf-8 -*-
import os
from django.conf import settings
from celery import Celery
from celery.schedules import crontab

celery_app = Celery('apple')

# Using a string here means the worker don't have to serialize
# the configuration object to child processes.
# - namespace='CELERY' means all celery-related configuration keys
#   should have a `CELERY_` prefix.
celery_app.config_from_object(settings, namespace='CELERY')

# 配置周期性任务
celery_app.conf.beat_schedule = {
    'clear_expired_message': {
        'task': 'mqtt.tasks.clear_expired_message',
        'schedule': crontab(hour=2, minute=0),
    }
}

# Load task modules from all registered Django app configs.
celery_app.autodiscover_tasks()

# -*- coding: utf-8 -*-
# Copyright 2015 gRPC authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""The Python implementation of the GRPC exhook server."""
import sys
import django
import json

django.setup()
from django.conf import settings
from concurrent import futures
import grpc
import exhook_pb2
import exhook_pb2_grpc
from mqtt.service.imservice import handle_publish_message, handle_delivered_message, handle_dropped_message, \
    save_mqtt_record, is_message_illegal
from mqtt.service import noticeservice, usernameservice
from mqtt import tasks
from utils.log import logfactory
from utils.common.util import gen_order_no
import datetime
from mqtt.cache import UserNameClientid
from mqtt.constant import EChatType
import traceback

logger = logfactory.get_logger(__name__)


class HookProvider(exhook_pb2_grpc.HookProviderServicer):

    def OnProviderLoaded(self, request, context):
        specs = [
            exhook_pb2.HookSpec(name="client.connected"),
            exhook_pb2.HookSpec(name="client.subscribe"),
            exhook_pb2.HookSpec(name="message.publish"),
            exhook_pb2.HookSpec(name="message.delivered"),
            exhook_pb2.HookSpec(name="message.dropped"),
            exhook_pb2.HookSpec(name="client.disconnected")
        ]
        return exhook_pb2.LoadedResponse(hooks=specs)

    def OnProviderUnloaded(self, request, context):
        return exhook_pb2.EmptySuccess()

    def OnClientConnected(self, request, context):
        logger.info('OnClientConnected:{}'.format(str(request).replace('\n', '').replace('\r', '')))
        username = request.clientinfo.username
        if username != request.clientinfo.clientid:
            last_clientid = UserNameClientid(username).get()
            if last_clientid and last_clientid != request.clientinfo.clientid:
                usernameservice.send_other_device_login_message(
                    to_topic=last_clientid
                )
            if last_clientid != request.clientinfo.clientid:
                UserNameClientid(username).set(request.clientinfo.clientid)
        # 用户上线通知
        noticeservice.notice_third_user_online(
            username=request.clientinfo.username,
        )
        return exhook_pb2.EmptySuccess()

    def OnClientDisconnected(self, request, context):
        logger.info('OnClientDisconnected:{}'.format(str(request).replace('\n', '').replace('\r', '')))
        username = request.clientinfo.username
        UserNameClientid(username).delete()
        # 用户下线通知
        noticeservice.notice_third_user_offline(
            username=request.clientinfo.username,
            reason=request.reason
        )
        return exhook_pb2.EmptySuccess()

    def OnClientSubscribe(self, request, context):
        # 订阅回调发送离线消息
        logger.info("OnClientSubscribe:{}".format(str(request).replace('\n', '').replace('\r', '')))
        for topic_filters in request.topic_filters:
            topic_name = topic_filters.name
            logger.info("topic_name:{}".format(topic_name))
            # 只对订阅自己的username的消息转发
            if topic_name != request.clientinfo.username:
                return exhook_pb2.EmptySuccess()

            # 订阅返回成功前发送离线消息，eqmx没有收到订阅成功返回，消息就会进入drop,报没有订阅者的错误
            tasks.send_offline_msg.s(
                to_username=topic_name
            ).apply_async()
        logger.info("subscribe, username:{}".format(request.clientinfo.username))
        return exhook_pb2.EmptySuccess()

    def OnMessagePublish(self, request, context):
        logger.info('OnMessagePublish:{}'.format(str(request).replace('\n', '').replace('\r', '')))
        # 获取emqx中的from,真实的发送者也就是clientid(可能是系统转发)， payload中的from为展示的发送者
        real_from_user = request.message.__getattribute__('from')
        try:
            mqtt_message_id = request.message.id
            logger.info("real_from_user:{}".format(real_from_user))
            payload_dict = json.loads(request.message.payload)

            # 广播类型消息不保存
            if payload_dict.get('chat_type') == EChatType.BROADCAST.value:
                return exhook_pb2.EmptySuccess()
            # 群发消息里面的to改为单个用户
            if not payload_dict.get('to'):
                payload_dict['to'] = request.message.topic
            if payload_dict.get('message_no'):
                logger.info('message_no:{} exist save_mqtt_record'.format(payload_dict.get('message_no')))
                message_no = payload_dict.get('message_no')
                save_mqtt_record(mqtt_message_id=mqtt_message_id, message_no=message_no)
            else:
                # 不存在 message_no 就是第一次发送， 存在就是离线转发
                if is_message_illegal(payload_dict=payload_dict, real_from_user=real_from_user):
                    logger.info("Illegal message -> {}:{}".format(real_from_user, payload_dict))
                    response = exhook_pb2.ValuedResponse()
                    response.type = 2  # STOP_AND_RETURN
                    response.message.CopyFrom(request.message)
                    # 返回空消息
                    response.message.payload = b''
                    return response

                message_no = gen_order_no()
                logger.info('message_no not exist save_msg, message_no:{}'.format(message_no))
                offline_send = bool(payload_dict.get('offline_send', True))
                if offline_send:
                    handle_publish_message(
                        send_user=real_from_user,
                        to_user=request.message.topic,
                        from_user=payload_dict.get('from', ''),
                        topic=request.message.topic,
                        mqtt_message_id=mqtt_message_id,
                        message_no=message_no,
                        payload_dict=payload_dict
                    )
                # 通知第三方服务,只在第一次发送消息的时候推送
                payload_dict['message_id'] = mqtt_message_id
                noticeservice.callback(post_data=payload_dict)
        except Exception:
            logger.info("OnMessagePublish:username:{} except:{}".format(real_from_user, traceback.format_exc()))
            response = exhook_pb2.ValuedResponse()
            response.type = 2  # STOP_AND_RETURN
            response.message.CopyFrom(request.message)
            # 返回空消息
            response.message.payload = b''
            return response
        return exhook_pb2.EmptySuccess()

    def OnMessageDelivered(self, request, context):
        logger.info('OnMessageDelivered:{}'.format(str(request).replace('\n', '').replace('\r', '')))
        try:
            handle_delivered_message(mqtt_message_id=request.message.id)
        except Exception:
            logger.info("OnMessageDelivered:message_id:{}:error:{}".format(request.message.id, traceback.format_exc()))
        return exhook_pb2.EmptySuccess()

    def OnMessageDropped(self, request, context):
        logger.info('OnMessageDropped:{}'.format(str(request).replace('\n', '').replace('\r', '')))
        try:
            handle_dropped_message(mqtt_message_id=request.message.id)
        except Exception:
            logger.info("OnMessageDropped:message_id:{}:error:{}".format(request.message.id, traceback.format_exc()))
        return exhook_pb2.EmptySuccess()


def start_server(port: int):
    try:
        if settings.PROD:
            max_workers = 100
        else:
            max_workers = 2
        server = grpc.server(futures.ThreadPoolExecutor(max_workers=max_workers))
        exhook_pb2_grpc.add_HookProviderServicer_to_server(HookProvider(), server)
        server.add_insecure_port('[::]:{}'.format(port))
        logger.info("exhook_server start listen on 0.0.0.0:{}".format(port))
        server.start()
        server.wait_for_termination()
    except Exception as e:
        logger.info(e)


if __name__ == '__main__':
    if len(sys.argv) <= 1:
        port = 9000
    else:
        port = int(sys.argv[1])
    start_server(port)

# Bitwarden (unofficial) CLI plugin

This plugin adds completion for [rbw](https://github.com/doy/rbw), an unofficial
CLI for [Bitwarden](https://bitwarden.com).

To use it, add `rbw` to the plugins array in your zshrc file:

```zsh
plugins=(... rbw)
```

This plugin does not add any aliases.
